# Imparare il ragtime a due mani — guida agli esercizi

`[sessione 3c88c123, 03/10/2026]` — secondo corso della serie (dopo boogie e blues), stessa formula.
Esercizi generati nota per nota per principiante adulto, con **Synthesia**. Verificati
armonicamente: ogni nota della destra appartiene all'accordo/scala della battuta.

Il ragtime e' il nonno del jazz: musica **allegra, in tonalita' maggiore**, nata per il pianoforte.
Due ingredienti lo definiscono, e sono proprio i nostri due filoni di studio:

- **La mano sinistra fa lo &ldquo;stride&rdquo;**: un *basso-accordo, basso-accordo* regolare
  (oom-pah oom-pah) che tiene il tempo come una banda in marcia.
- **La mano destra &egrave; sincopata**: gli accenti cadono *fra* i tempi, non sui tempi. E' quel
  &ldquo;zoppicare&rdquo; allegro che rende il ragtime riconoscibile.

**Regola d'oro (come sempre): prima la mano sinistra, da sola, lentissima.** Lo stride e' il motore.
Quando gira da solo, la destra sincopata ci si appoggia sopra.

---

## Come preparare Synthesia

Identico agli altri corsi: cavo **USB &ldquo;TO HOST&rdquo;**, seleziona la tastiera come ingresso,
apri il file `.mid`, attiva la **Modalita' di attesa**, studia **una mano alla volta**. Per i
dettagli vedi la guida nella cartella `Esercizi Boogie Woogie`.

---

## La progressione (10 esercizi, in DO salvo indicazione)

| # | File | Cosa impari | Mani |
|---|---|---|---|
| 1 | `..._01_Riscaldamento_DO` | muovere le dita sulla scala di DO maggiore | entrambe |
| 2 | `..._02_Stride_base_DO` | lo **stride** di base: basso-accordo in DO | solo sinistra |
| 3 | `..._03_Stride_I_IV_V` | lo stride su **DO-FA-SOL7**: la forma armonica | solo sinistra |
| 4 | `..._04_Sincope_destra` | la **sincope** 3+3+2: il respiro tipico del ragtime | due mani (semplice) |
| 5 | `..._05_Melodia_sincopata` | una melodia sincopata su basso tenuto | due mani |
| 6 | `..._06_Due_mani` | mettere insieme melodia sincopata + stride (8 battute) | due mani |
| 7 | `..._07_Stride_in_SOL` | lo stride in **SOL**: una nuova tonalita' | solo sinistra |
| 8 | `..._08_Cakewalk` | il **cakewalk**: ritmo puntato di marcia + stride | due mani |
| 9 | `..._09_Strain_A` | uno **strain** di 16 battute: una vera frase di ragtime | due mani |
| 10 | `..._10_Pezzo_finale` | lo strain con **turnaround** finale (SOL7 &rarr; DO) | due mani |

Tempi lenti apposta (69-78 BPM). Ogni file ha il suo **MP3**: ascolta prima, poi suona.

---

## Le due cose che contano nel ragtime

- **Lo stride regolare.** La sinistra non deve mai esitare: basso grave sul tempo 1 e 3, accordo
  medio sul 2 e 4. E' una marcia. Studiala da sola finche' non ci pensi piu'.
- **La sincope rilassata.** Gli accenti &ldquo;in ritardo&rdquo; (il ritmo 3+3+2) vanno sentiti, non
  contati a fatica. Ascolta tanto l'MP3: l'orecchio impara la sincope molto prima della testa.

Valgono le solite regole: sinistra prima da sola; poco e spesso; lento batte veloce; rilassa spalle e
polsi. Non e' una gara.

---

## Onesta' sui file

Generati nota per nota (non trascritti), con le mani gia' separate, e **verificati**: un controllo
automatico ha confermato che ogni nota della destra appartiene all'accordo o alla scala maggiore della
battuta (52 battute controllate, 0 fuori armonia). Sono esercizi *didattici* essenziali: ti danno i
mattoni veri del ragtime (stride, sincope 3+3+2, cakewalk, strain). **Non** sostituiscono un
insegnante ne' i grandi classici: quando questi ti vengono bene, il passo naturale sono i ragtime di
pubblico dominio (Scott Joplin: *The Entertainer*, *Maple Leaf Rag*), che si trovano liberamente in
MIDI.

Buon divertimento, e un tasto alla volta.
